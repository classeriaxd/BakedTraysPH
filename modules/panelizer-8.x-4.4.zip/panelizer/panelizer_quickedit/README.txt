Panelizer Quick Edit
---------
This module contains customizations which allow Panelized Entities to be edited
inline with Quick Edit. It is separate from the Panelizer project as not all
users need this functionality.
