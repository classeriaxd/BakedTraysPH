<?php

namespace Drupal\panels_ipe\Exception;

/**
 * Defines an exception thrown when a request object has no contents.
 */
class EmptyRequestContentException extends \Exception {}
